#!/bin/bash

# Iniciar FastAPI
uvicorn backend.main:app --host 0.0.0.0 --port 8000 &

# Iniciar Streamlit
streamlit run frontend/app.py --server.port=8501 --server.address=0.0.0.0
