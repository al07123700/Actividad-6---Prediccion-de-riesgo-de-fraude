import streamlit as st
import requests

st.title("Fraud Detection")

transaction_id = st.number_input("Transaction ID", min_value=1, value=1)
amount = st.number_input("Amount", min_value=0.0, value=100.0)
transaction_hour = st.slider("Transaction Hour", 0, 23, 10)

merchant_category = st.selectbox(
    "Merchant Category",
    ["Electronics", "Travel", "Grocery", "Food", "Clothing"]
)

foreign_transaction = st.selectbox("Foreign Transaction", [0, 1])
location_mismatch = st.selectbox("Location Mismatch", [0, 1])
device_trust_score = st.slider("Device Trust Score", 0.0, 1.0, 0.7)
velocity_last_24h = st.number_input("Velocity Last 24h", min_value=0.0, value=3.0)
cardholder_age = st.number_input("Cardholder Age", min_value=18, value=28)

if st.button("Predict Fraud"):
    data = {
        "transaction_id": transaction_id,
        "amount": amount,
        "transaction_hour": transaction_hour,
        "merchant_category": merchant_category,
        "foreign_transaction": foreign_transaction,
        "location_mismatch": location_mismatch,
        "device_trust_score": device_trust_score,
        "velocity_last_24h": velocity_last_24h,
        "cardholder_age": cardholder_age
    }

    response = requests.post("http://localhost:8000/predict", json=data)

    if response.status_code == 200:
        result = response.json()
        st.success(f"Fraud Probability: {result['fraud_probability']}")
        st.write(f"Is Fraud: {result['is_fraud']}")
    else:
        st.error("Error calling API")
