import joblib
from pathlib import Path

MODEL_PATH = Path(__file__).parent.parent / "model" / "best_model.pkl"

def load_model():
    return joblib.load(MODEL_PATH)

model = load_model()