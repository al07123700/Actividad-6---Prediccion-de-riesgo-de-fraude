from pydantic import BaseModel

class FraudRequest(BaseModel):
    transaction_id: int
    amount: float
    transaction_hour: int
    merchant_category: str
    foreign_transaction: int
    location_mismatch: int
    device_trust_score: float
    velocity_last_24h: float
    cardholder_age: int

class FraudResponse(BaseModel):
    fraud_probability: float
    is_fraud: bool
