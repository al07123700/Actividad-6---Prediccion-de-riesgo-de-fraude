from fastapi import FastAPI
from backend.schemas import FraudRequest, FraudResponse
from backend.model_loader import model
import pandas as pd

app = FastAPI(title="Fraud Risk API")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict", response_model=FraudResponse)
def predict(request: FraudRequest):

    # Convertir el request a DataFrame con nombres de columnas
    data = pd.DataFrame([request.dict()])

    # Predecir
    proba = model.predict_proba(data)[0, 1]

    return FraudResponse(
        fraud_probability=float(proba),
        is_fraud=proba >= 0.5
    )

